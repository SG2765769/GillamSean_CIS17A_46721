/* 
 * Author: Sean Gillam
 * Date: 2020-06-29
 */

//System Libraries
#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    //Initialize or input data here
    int x;
    double y;
    cin >> x;
    cin >> y;
    //Format and display outputs here
    cout << x << endl;
    cout << y << endl;
    cout << "Hello World     " << endl;
    cout << "	Tab it!" << endl;
    cout << "Compare . . . to space   ";
    //Exit stage left
    return 0;
}