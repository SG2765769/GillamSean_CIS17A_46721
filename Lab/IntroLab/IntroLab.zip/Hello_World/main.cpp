/* 
 * File:   main.cpp
 * Author: Sean Gillam
 * Class: CIS-17A-46721
 * Created on June 29, 2020, 9:22 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;
int main() 
{
    cout << "Hello World";
    return 0;
}

